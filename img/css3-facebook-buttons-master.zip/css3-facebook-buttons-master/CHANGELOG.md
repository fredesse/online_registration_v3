== HEAD

* Optimize icon sprite.
* Fix `a:visited` color style changing button text color.

== 1.0.0 (May 20, 2013)
